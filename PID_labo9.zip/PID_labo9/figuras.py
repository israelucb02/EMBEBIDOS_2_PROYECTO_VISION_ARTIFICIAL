import cv2
import numpy as np

class ColorRange:
    def __init__(self):
        self.color_ranges = {
            "Azul": (
                [(np.array([86, 48, 0]), np.array([114, 255, 255]))],
                (255, 0, 0)  # Azul BGR
            ),
            "Rojo": (
                [
                    np.array([0, 70, 100]), np.array([10, 255, 255]),
                    np.array([160, 70, 100]), np.array([179, 255, 255])
                ],
                (0, 0, 255)  # Rojo BGR
            ),
            "Verde": (
                [(np.array([40, 50, 50]), np.array([85, 255, 255]))],
                (0, 255, 0)  # Verde BGR
            ),
            "Amarillo": (
                [(np.array([20, 100, 100]), np.array([35, 255, 255]))],
                (0, 255, 255)  # Amarillo BGR
            )
        }

    def get_all_ranges(self):
        return self.color_ranges.items()


class ObjectFollower:
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.range_data = ColorRange()
        self.kernel = np.ones((5, 5), np.uint8)

    def apply_clahe(self, frame):
        lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        limg = cv2.merge((cl, a, b))
        corrected = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        return corrected

    def run(self):
        print("Presiona ESC para salir")

        while True:
            ret, frame = self.cap.read()
            if not ret:
                break

            # 🔽 Oscurecer la imagen
            #frame = cv2.convertScaleAbs(frame, alpha=0.7, beta=0)

            # 🔧 Corrección de contraste
            blurred = cv2.GaussianBlur(frame, (5, 5), 0)
            enhanced = self.apply_clahe(blurred)
            hsv = cv2.cvtColor(enhanced, cv2.COLOR_BGR2HSV)

            for color_name, (ranges, draw_color) in self.range_data.get_all_ranges():
                mask = None

                if color_name == "Rojo":
                    lower1, upper1 = ranges[0], ranges[1]
                    lower2, upper2 = ranges[2], ranges[3]
                    mask1 = cv2.inRange(hsv, lower1, upper1)
                    mask2 = cv2.inRange(hsv, lower2, upper2)
                    mask = cv2.bitwise_or(mask1, mask2)
                else:
                    for lower, upper in ranges:
                        temp_mask = cv2.inRange(hsv, lower, upper)
                        mask = temp_mask if mask is None else cv2.bitwise_or(mask, temp_mask)

                # 🧼 Limpieza con morfología
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, self.kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for cnt in contours:
                    area = cv2.contourArea(cnt)
                    if area > 1000:
                        # Ajuste de precisión
                        approx = cv2.approxPolyDP(cnt, 0.03 * cv2.arcLength(cnt, True), True)
                        shape = "Desconocido"

                        if len(approx) == 3:
                            shape = "Triángulo"
                        elif len(approx) == 4:
                            x, y, w, h = cv2.boundingRect(approx)
                            aspect_ratio = float(w) / h
                            shape = "Cuadrado" if 0.9 < aspect_ratio < 1.1 else "Rectángulo"
                        elif len(approx) > 5:
                            circularity = 4 * np.pi * area / (cv2.arcLength(cnt, True) ** 2)
                            if circularity > 0.7:
                                shape = "Círculo"

                        # Dibuja y etiqueta
                        cv2.drawContours(frame, [cnt], -1, draw_color, 2)
                        x, y = approx.ravel()[0], approx.ravel()[1]
                        cv2.putText(frame, f"{color_name}: {shape}", (x, y - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, draw_color, 2)

            resized = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            cv2.imshow("Detector de Formas y Colores", resized)

            if cv2.waitKey(30) & 0xFF == 27:
                break

        self.cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    follower = ObjectFollower()
    follower.run()
