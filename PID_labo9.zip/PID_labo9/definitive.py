import cv2
import numpy as np

def nothing(x):
    pass

# 🔧 Crear ventana antes de los sliders
cv2.namedWindow("Configuración")
cv2.waitKey(1)  # Solución para asegurar que la ventana existe antes de crear sliders

# 🔧 Sliders para calibrar
cv2.createTrackbar("Aprox %", "Configuración", 3, 10, nothing)      # sensibilidad approxPolyDP
cv2.createTrackbar("Área mínima", "Configuración", 1000, 10000, nothing)

# 📷 Captura desde la cámara
cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 🔄 Preprocesamiento
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 50, 150)

    # 🧪 Leer sliders
    approx_percent = cv2.getTrackbarPos("Aprox %", "Configuración") / 100.0
    area_threshold = cv2.getTrackbarPos("Área mínima", "Configuración")

    # 🔍 Detección de contornos
    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area > area_threshold:
            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, approx_percent * peri, True)

            shape = "Desconocido"
            if len(approx) == 3:
                shape = "Triángulo"
            elif len(approx) == 4:
                x, y, w, h = cv2.boundingRect(approx)
                aspect_ratio = float(w) / h
                shape = "Cuadrado" if 0.9 < aspect_ratio < 1.1 else "Rectángulo"
            elif len(approx) > 5:
                circularity = 4 * np.pi * area / (peri ** 2)
                if circularity > 0.7:
                    shape = "Círculo"

            cv2.drawContours(frame, [approx], -1, (0, 255, 0), 2)
            x, y = approx.ravel()[0], approx.ravel()[1]
            cv2.putText(frame, shape, (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # 🖼 Mostrar ventanas
    cv2.imshow("Calibrador de Figuras", frame)
    cv2.imshow("Bordes", edged)

    if cv2.waitKey(1) & 0xFF == 27:  # Presiona ESC para salir
        break

cap.release()
cv2.destroyAllWindows()
