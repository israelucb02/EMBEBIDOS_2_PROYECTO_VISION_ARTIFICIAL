import cv2
import numpy as np
import serial  # UART

class ColorDetector:
    def __init__(self):
        self.cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
        if not self.cap.isOpened():
            raise ValueError("No se pudo abrir la cámara. Verifica la conexión.")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
        print("Cámara configurada correctamente")

        self.serial = serial.Serial('/dev/ttyACM0', 9600, timeout=1)

        # 🎯 Objetivo a detectar
        self.color_objetivo = "Verde"        # Cambia según necesidad
        self.forma_objetivo = "Cuadro"      # Cambia según necesidad

        # Parámetros para distancia (calibra focal_length)
        self.known_width = 8.5  # en cm
        self.focal_length = 700  # en píxeles

    def distance_to_camera(self, perceived_width):
        return (self.known_width * self.focal_length) / perceived_width if perceived_width > 0 else float('inf')

    def detect_colors(self):
        print("\nIniciando detección de colores. Presiona 'q' para salir")
        cv2.namedWindow("Detección de Colores", cv2.WINDOW_NORMAL)

        color_ranges = {
            "Rojo": [
                (np.array([0, 100, 120]), np.array([10, 255, 255])),
                (np.array([160, 100, 120]), np.array([179, 255, 255])),
                (0, 0, 255)
            ],
            "Azul": [
                (np.array([95, 70, 80]), np.array([130, 255, 255])),
                None,
                (255, 0, 0)
            ],
            "Verde": [
                (np.array([35, 70, 80]), np.array([85, 255, 255])),
                None,
                (0, 255, 0)
            ],
            "Naranja": [
                (np.array([0, 7, 222]), np.array([67, 103, 255])),
                None,
                (0, 140, 255)
            ],
            "Morado": [
                (np.array([122, 0, 180]), np.array([145, 255, 255])),
                None,
                (255, 0, 255)
            ]
        }

        while True:
            ret, frame = self.cap.read()
            if not ret:
                print("No se pudo leer el frame de la cámara.")
                break

            total_detectadas = 0
            coincidencias = 0
            distancia_menor_20 = False

            blurred = cv2.GaussianBlur(frame, (5, 5), 0)
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

            for color_name, (range1, range2, draw_color) in color_ranges.items():
                if color_name == "Rojo":
                    frame_dark = cv2.convertScaleAbs(frame, alpha=0.7, beta=0)
                    blurred_dark = cv2.GaussianBlur(frame_dark, (5, 5), 0)
                    hsv_proc = cv2.cvtColor(blurred_dark, cv2.COLOR_BGR2HSV)
                    mask1 = cv2.inRange(hsv_proc, range1[0], range1[1])
                    mask2 = cv2.inRange(hsv_proc, range2[0], range2[1])
                    mask = cv2.bitwise_or(mask1, mask2)
                else:
                    hsv_proc = hsv
                    mask = cv2.inRange(hsv_proc, range1[0], range1[1])

                kernel = np.ones((5, 5), np.uint8)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for cnt in contours:
                    area = cv2.contourArea(cnt)
                    if area < 1000:
                        continue

                    if color_name == "Rojo":
                        mask_temp = np.zeros(mask.shape, dtype=np.uint8)
                        cv2.drawContours(mask_temp, [cnt], -1, 255, -1)
                        h, s, v = cv2.mean(hsv_proc, mask=mask_temp)[:3]
                        if s < 120 or v < 120:
                            continue

                    peri = cv2.arcLength(cnt, True)
                    approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
                    num_vertices = len(approx)

                    shape = None
                    size = 0
                    if num_vertices == 3:
                        shape = "Triángulo"
                        size = peri / 3
                    elif num_vertices == 4:
                        rect = cv2.minAreaRect(cnt)
                        width, height = rect[1]
                        ar = max(width, height) / min(width, height) if min(width, height) > 0 else 0
                        if 0.85 <= ar <= 1.15:
                            shape = "Cuadro"
                            size = max(width, height)
                        else:
                            continue
                    else:
                        circularity = 4 * np.pi * area / (peri ** 2) if peri > 0 else 0
                        if circularity > 0.75:
                            shape = "Círculo"
                            (cx, cy), radius = cv2.minEnclosingCircle(cnt)
                            size = 2 * radius
                        else:
                            continue

                    if shape:
                        total_detectadas += 1
                        if color_name == self.color_objetivo and shape == self.forma_objetivo:
                            coincidencias += 1
                            distancia = self.distance_to_camera(size)
                            print(f"Distancia: {distancia:.1f} cm")
                            if distancia < 22:
                                distancia_menor_20 = True

            # UART logic
            if distancia_menor_20:
                mensaje = "objetos"
            elif coincidencias == 1:
                mensaje = "uno"
            elif coincidencias > 1:
                mensaje = "objetos"
            else:
                mensaje = "nada"

            print(f"📤 UART: {mensaje}")
            self.serial.write((mensaje + "\n").encode("utf-8"))

            cv2.putText(frame, f"Figuras detectadas: {total_detectadas}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
            cv2.imshow("Detección de Colores", frame)

            if cv2.waitKey(30) & 0xFF == ord('q'):
                break

        self.cap.release()
        self.serial.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
        detector = ColorDetector()
        detector.detect_colors()
    except Exception as e:
        print(f"Error: {e}")
        cv2.destroyAllWindows()
