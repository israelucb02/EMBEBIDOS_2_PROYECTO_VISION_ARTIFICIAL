import cv2
import numpy as np
import serial
import time

class ObjectFollower:
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

       # self.serial = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
        time.sleep(2)

    def run(self):
        while True:
            ret, frame = self.cap.read()
            if not ret:
                break

            # Suavizado
            blurred = cv2.GaussianBlur(frame, (5, 5), 0)

            # Convertir a HSV
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

            # Rangos para rojo intenso
            lower_red1 = np.array([0, 100, 120])
            upper_red1 = np.array([10, 255, 255])
            lower_red2 = np.array([160, 100, 120])
            upper_red2 = np.array([179, 255, 255])

            # Crear máscaras y combinarlas
            mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
            mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
            mask = cv2.bitwise_or(mask1, mask2)

            # Encontrar contornos
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            red_objects = 0

            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area > 1000:
                    # Crear una máscara del contorno individual
                    mask_temp = np.zeros(mask.shape, dtype=np.uint8)
                    cv2.drawContours(mask_temp, [cnt], -1, 255, -1)

                    # Medir promedio HSV del área
                    mean_val = cv2.mean(hsv, mask=mask_temp)
                    h, s, v = mean_val[:3]

                    if s > 120 and v > 120:
                        red_objects += 1
                        cv2.drawContours(frame, [cnt], -1, (0, 255, 0), 2)

            # Mostrar el número detectado
            cv2.putText(frame, f"Objetos rojos detectados: {red_objects}",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            # Enviar mensaje por UART
            if red_objects == 0:
                message = "nada"
            elif red_objects == 1:
                message = "uno"
            else:
                message = "objetos"

            # Mostrar imagen reducida
            resized = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            cv2.imshow("Seguidor (rojo intenso)", resized)

            if cv2.waitKey(30) & 0xFF == 27:
                break

        self.cap.release()
        self.serial.close()
        cv2.destroyAllWindows()

ObjectFollower().run()
