import cv2
import numpy as np

class ColorDetector:
    def __init__(self):
        self.cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
        if not self.cap.isOpened():
            raise ValueError("No se pudo abrir la cámara. Verifica la conexión.")
        
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
        print("Cámara configurada correctamente")

    def detect_colors(self):
        print("\nIniciando detección de colores. Presiona 'q' para salir")

        cv2.namedWindow("Detección de Colores", cv2.WINDOW_NORMAL)

        color_ranges = {
            "Rojo": [
                (np.array([0, 100, 120]), np.array([10, 255, 255])),
                (np.array([160, 100, 120]), np.array([179, 255, 255])),
                (0, 0, 255)
            ],
            "Azul": [
                (np.array([95, 70, 80]), np.array([130, 255, 255])),
                None,
                (255, 0, 0)
            ],
            "Verde": [
                (np.array([35, 70, 80]), np.array([85, 255, 255])),
                None,
                (0, 255, 0)
            ],
            "Naranja": [
                (np.array([0, 7, 222]), np.array([67, 103, 255])),
                None,
                (0, 140, 255)
            ],
            "Morado": [
                (np.array([122, 0, 180]), np.array([145, 255, 255])),
                None,
                (255, 0, 255)
            ]
        }

        while True:
            ret, frame = self.cap.read()
            if not ret:
                print("No se pudo leer el frame de la cámara.")
                break

            frame_center_x = frame.shape[1] // 2
            total_detectadas = 0  # 🔢 Contador por frame

            blurred = cv2.GaussianBlur(frame, (5, 5), 0)
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

            for color_name, (range1, range2, draw_color) in color_ranges.items():
                if color_name == "Rojo":
                    frame_dark = cv2.convertScaleAbs(frame, alpha=0.7, beta=0)
                    blurred_dark = cv2.GaussianBlur(frame_dark, (5, 5), 0)
                    hsv_proc = cv2.cvtColor(blurred_dark, cv2.COLOR_BGR2HSV)

                    mask1 = cv2.inRange(hsv_proc, range1[0], range1[1])
                    mask2 = cv2.inRange(hsv_proc, range2[0], range2[1])
                    mask = cv2.bitwise_or(mask1, mask2)
                else:
                    hsv_proc = hsv
                    mask = cv2.inRange(hsv_proc, range1[0], range1[1])

                kernel = np.ones((5, 5), np.uint8)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

                contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for cnt in contours:
                    area = cv2.contourArea(cnt)
                    if area < 1000:
                        continue

                    if color_name == "Rojo":
                        mask_temp = np.zeros(mask.shape, dtype=np.uint8)
                        cv2.drawContours(mask_temp, [cnt], -1, 255, -1)
                        mean_val = cv2.mean(hsv_proc, mask=mask_temp)
                        h, s, v = mean_val[:3]
                        if s < 120 or v < 120:
                            continue

                    peri = cv2.arcLength(cnt, True)
                    approx = cv2.approxPolyDP(cnt, 0.04 * peri, True)
                    num_vertices = len(approx)

                    shape = None
                    if num_vertices == 3:
                        shape = "Triángulo"
                    elif num_vertices == 4:
                        rect = cv2.minAreaRect(cnt)
                        box = cv2.boxPoints(rect)
                        box = np.int0(box)
                        width, height = rect[1]
                        ar = max(width, height) / min(width, height) if min(width, height) > 0 else 0
                        if 0.85 <= ar <= 1.15:
                            shape = "Cuadro"
                        else:
                            continue
                    else:
                        circularity = 4 * np.pi * area / (peri ** 2) if peri > 0 else 0
                        if circularity > 0.75:
                            shape = "Círculo"
                        else:
                            continue

                    if shape:
                        total_detectadas += 1  # ✅ Contador incrementa

                        if num_vertices == 4 and color_name == "Rojo":
                            rect = cv2.minAreaRect(cnt)
                            box = cv2.boxPoints(rect)
                            box = np.int0(box)
                            cv2.drawContours(frame, [box], 0, draw_color, 3)
                            x, y = int(rect[0][0]), int(rect[0][1])
                        elif num_vertices >= 5 and shape == "Círculo":
                            (cx, cy), radius = cv2.minEnclosingCircle(cnt)
                            center = (int(cx), int(cy))
                            radius = int(radius)
                            cv2.circle(frame, center, radius, draw_color, 3)
                            x, y = center[0], center[1] - radius
                        else:
                            cv2.drawContours(frame, [approx], 0, draw_color, 3)
                            M = cv2.moments(cnt)
                            x = int(M['m10'] / (M['m00'] + 1e-5))
                            y = int(M['m01'] / (M['m00'] + 1e-5))

                        error_x = x - frame_center_x
                        print(f"Detectado: {color_name} {shape} | Error X: {error_x}")

                        cv2.putText(frame, f"{color_name} {shape}", (x - 40, y - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, draw_color, 2)
                        cv2.line(frame, (frame_center_x, 0), (frame_center_x, frame.shape[0]), (255, 255, 255), 1)
                        cv2.putText(frame, f"ErrX: {error_x}", (x - 40, y + 25),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            # Mostrar contador global en la esquina superior
            cv2.putText(frame, f"Figuras detectadas: {total_detectadas}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)

            cv2.imshow("Detección de Colores", frame)

            if cv2.waitKey(30) & 0xFF == ord('q'):
                break

        self.cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    try:
        detector = ColorDetector()
        detector.detect_colors()
    except Exception as e:
        print(f"Error: {e}")
        cv2.destroyAllWindows()
