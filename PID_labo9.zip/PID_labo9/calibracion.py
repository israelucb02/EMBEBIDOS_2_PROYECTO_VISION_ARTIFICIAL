import cv2
import numpy as np

def nothing(x):
    pass

# Crear ventana con trackbars
cv2.namedWindow("Calibrador HSV")
cv2.createTrackbar("H Min", "Calibrador HSV", 0, 179, nothing)
cv2.createTrackbar("H Max", "Calibrador HSV", 179, 179, nothing)
cv2.createTrackbar("S Min", "Calibrador HSV", 0, 255, nothing)
cv2.createTrackbar("S Max", "Calibrador HSV", 255, 255, nothing)
cv2.createTrackbar("V Min", "Calibrador HSV", 0, 255, nothing)
cv2.createTrackbar("V Max", "Calibrador HSV", 255, 255, nothing)

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

print("Usa las trackbars para calibrar el color. Presiona ESC para salir.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    blurred = cv2.GaussianBlur(frame, (5, 5), 0)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

    # Leer valores de las trackbars
    h_min = cv2.getTrackbarPos("H Min", "Calibrador HSV")
    h_max = cv2.getTrackbarPos("H Max", "Calibrador HSV")
    s_min = cv2.getTrackbarPos("S Min", "Calibrador HSV")
    s_max = cv2.getTrackbarPos("S Max", "Calibrador HSV")
    v_min = cv2.getTrackbarPos("V Min", "Calibrador HSV")
    v_max = cv2.getTrackbarPos("V Max", "Calibrador HSV")

    lower = np.array([h_min, s_min, v_min])
    upper = np.array([h_max, s_max, v_max])

    mask = cv2.inRange(hsv, lower, upper)
    result = cv2.bitwise_and(frame, frame, mask=mask)

    # Mostrar resultados
    combined = np.hstack((frame, cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR), result))
    resized = cv2.resize(combined, (0, 0), fx=0.5, fy=0.5)
    cv2.imshow("Calibrador HSV", resized)

    if cv2.waitKey(30) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
